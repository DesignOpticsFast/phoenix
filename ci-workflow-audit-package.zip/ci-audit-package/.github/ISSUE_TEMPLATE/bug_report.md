---
name: Bug report
about: Report a problem
labels: bug
---

**Describe the bug**
What happened, and what did you expect?

**Repro steps**
1. …
2. …

**Environment**
- OS:
- Version / commit:

**Logs / screenshots**
