# Examples

## Sample Arrow Files

Real `.arrow` binary samples coming in Phase 2.1.  
For now, use these JSON specs to validate Vega-Lite rendering.

To generate sample Arrow files:
```bash
python scripts/generate_sample_data.py --contract mtf --output docs/data_contracts/examples/mtf_sample.arrow
```
