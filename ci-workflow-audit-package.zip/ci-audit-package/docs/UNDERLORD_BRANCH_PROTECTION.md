# UnderLord Branch Protection (Phoenix)

This file seeds checks (PR Guard + CodeQL) so they can be selected in the branch protection UI.
After checks complete, this PR will be closed without merging.
- Phoenix branch protection validated at 2025-10-10T22:14:48Z
